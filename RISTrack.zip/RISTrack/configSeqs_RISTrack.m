function seqs=configSeqs_RISTrack

DTB70_Animal1 = {struct('name','Animal1','path','.\seq\Animal1\','startFrame',1,'endFrame',147,'nz',5,'ext','jpg','init_rect',[0,0,0,0])};

seqs = DTB70_Animal1;
